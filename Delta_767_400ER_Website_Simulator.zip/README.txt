# Delta 767-400ER Flight Simulator

A browser-based 3D-style arcade flight simulator prototype.

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox).
3. If your browser blocks ES modules from local files, run a local server from this folder:
   - Python: `python -m http.server 8000`
   - Then open `http://localhost:8000`

The 3D engine is loaded from jsDelivr, so an internet connection is needed.

## Publish free with GitHub Pages
1. Sign in or create a free GitHub account.
2. Create a new **public** repository, e.g. `delta-767-simulator`.
3. Upload `index.html` to the repository root.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Choose `main` and `/ (root)`, then Save.
7. Wait for GitHub Pages to publish the site. The public URL will look like:
   `https://YOUR-USERNAME.github.io/delta-767-simulator/`

## Controls
- Up / Down: throttle
- W / S: pitch
- A / D: roll
- F: cycle flaps
- G: landing gear
- B: brakes
- E: engine on/off
- C: switch external / cockpit camera
- Space: pause
- R: reset

## Notes
This is a simplified arcade-style simulator, not an aircraft training device or accurate 767 performance model. The aircraft is a custom procedural 3D approximation. The Three.js module is loaded from a CDN, so the page needs internet access.
